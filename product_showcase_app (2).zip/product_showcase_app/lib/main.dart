import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:product_showcase_app/providers/auth_provider.dart';
import 'package:product_showcase_app/providers/product_provider.dart';
import 'package:product_showcase_app/screens/auth/login_screen.dart';
import 'package:product_showcase_app/screens/auth/register_screen.dart';
import 'package:product_showcase_app/screens/auth/forgot_password.dart';
import 'package:product_showcase_app/screens/auth/otp_verification.dart';
import 'package:product_showcase_app/screens/home/home_screen.dart';
import 'package:product_showcase_app/screens/product/product_detail.dart';
import 'package:product_showcase_app/models/product.dart';
import 'package:product_showcase_app/screens/splash_screen.dart';
void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => AuthProvider()),
        ChangeNotifierProvider(create: (_) => ProductProvider()),
      ],
      child: MaterialApp(
        title: 'Product Showcase',
        theme: ThemeData(
          primarySwatch: Colors.blue,
        ),
        initialRoute: '/splash',
        routes: {
          '/splash': (context) => SplashScreen(),
          '/login': (context) => LoginScreen(),
          '/register': (context) => RegisterScreen(),
          '/forgot-password': (context) => ForgotPasswordScreen(),
          '/otp-verification': (context) => OtpVerificationScreen(),
          '/home': (context) => HomeScreen(),
          '/product-detail': (context) {
            final product = ModalRoute.of(context)!.settings.arguments as Product;
            return ProductDetailScreen(product: product);
          },
        },
      ),
    );
  }
}