class AuthProvider with ChangeNotifier {
  final AuthService _authService = AuthService();
  bool _isLoading = false;
  String? _errorMessage;

  bool get isLoading => _isLoading;
  String? get errorMessage => _errorMessage;

  Future<bool> register(String name, String email, String password) async {
    _isLoading = true;
    notifyListeners();
    
    try {
      final success = await _authService.register(name, email, password);
      if (success) {
        await _authService.storeToken('dummy_token_${DateTime.now().millisecondsSinceEpoch}');
      }
      _isLoading = false;
      notifyListeners();
      return success;
    } catch (e) {
      _errorMessage = e.toString();
      _isLoading = false;
      notifyListeners();
      return false;
    }
  }

  // Similar methods for login, forgotPassword, verifyOtp, logout
}