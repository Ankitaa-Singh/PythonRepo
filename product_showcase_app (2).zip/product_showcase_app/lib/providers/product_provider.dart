class ProductProvider with ChangeNotifier {
  final ApiService _apiService = ApiService();
  List<Product> _products = [];
  List<Product> _filteredProducts = [];
  bool _isLoading = false;
  String? _errorMessage;
  String? _selectedCategory;
  double? _minPrice;
  double? _maxPrice;

  List<Product> get products => _filteredProducts;
  bool get isLoading => _isLoading;
  String? get errorMessage => _errorMessage;
  List<String> get categories => [
    'smartphones',
    'laptops',
    'fragrances',
    'skincare',
    'groceries',
    'home-decoration'
  ];

  Future<void> fetchProducts() async {
    _isLoading = true;
    notifyListeners();
    
    try {
      _products = await _apiService.fetchProducts();
      _filteredProducts = _products;
      _isLoading = false;
      notifyListeners();
    } catch (e) {
      _errorMessage = e.toString();
      _isLoading = false;
      notifyListeners();
    }
  }

  void filterProducts({String? category, double? minPrice, double? maxPrice}) {
    _selectedCategory = category;
    _minPrice = minPrice;
    _maxPrice = maxPrice;
    
    _filteredProducts = _products.where((product) {
      bool matchesCategory = category == null || product.category == category;
      bool matchesPrice = true;
      
      if (minPrice != null) {
        matchesPrice = matchesPrice && product.price >= minPrice;
      }
      
      if (maxPrice != null) {
        matchesPrice = matchesPrice && product.price <= maxPrice;
      }
      
      return matchesCategory && matchesPrice;
    }).toList();
    
    notifyListeners();
  }
}